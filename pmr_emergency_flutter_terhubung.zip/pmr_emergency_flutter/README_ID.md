# PMR EMERGENCY — proyek Flutter awal

Paket ini sudah diisi URL Supabase dan publishable key yang diberikan di percakapan.

## Isi tahap ini
- Kerangka aplikasi Flutter berbahasa Indonesia.
- Koneksi awal Supabase.
- Daftar akun dan masuk menggunakan email/kata sandi.
- Alur GitHub Actions untuk membuat APK Android secara cloud.

## Batasan penting
Ini BELUM APK jadi dan BELUM aplikasi SOS yang siap dipakai. Tombol DARURAT, grup sekolah, pembagian anggota per sekolah, GPS, push notification, serta alur tanggap darurat belum dibangun/diuji. Jangan gunakan untuk keadaan darurat nyata.

## Cara membuat APK nanti
Unggah isi folder proyek ini ke repository GitHub. Workflow `.github/workflows/build-android.yml` akan membangun APK setelah workflow dijalankan. Panduan langkah demi langkah akan diberikan di chat.

## Keamanan
- Publishable key boleh berada di aplikasi; Row Level Security (RLS) harus tetap aktif.
- Jangan pernah menaruh `service_role` key atau secret key di aplikasi atau repository.
- Gunakan proyek Supabase khusus PMR EMERGENCY, bukan proyek website FORPIS.
