# PMR EMERGENCY — paket diagnostik koneksi

Paket ini mempertahankan URL dan publishable key Supabase yang sudah diberikan untuk proyek PMR EMERGENCY.

## Perubahan
- Pesan `Failed host lookup` ditampilkan sebagai masalah resolusi DNS/koneksi perangkat, bukan kesalahan kata sandi.
- Workflow membangkitkan proyek Android Flutter dan memverifikasi izin `android.permission.INTERNET` sebelum build.

## Penting
Perubahan pesan error dan izin internet **tidak dapat memperbaiki DNS perangkat dengan sendirinya**. Karena Chrome dapat membuka endpoint Supabase tetapi aplikasi belum bisa, penyebab jaringan khusus aplikasi/perangkat masih perlu ditelusuri. Jangan gunakan aplikasi ini untuk keadaan darurat nyata; fitur SOS belum dibangun.

## Keamanan
Publishable key boleh berada di aplikasi. Jangan pernah memasukkan `service_role` atau secret key ke aplikasi atau GitHub.
