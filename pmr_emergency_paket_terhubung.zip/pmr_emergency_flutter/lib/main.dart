import 'dart:io';

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'supabase_config.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: supabaseUrl,
    anonKey: supabasePublishableKey,
  );
  runApp(const PmrEmergencyApp());
}

final supabase = Supabase.instance.client;

class PmrEmergencyApp extends StatelessWidget {
  const PmrEmergencyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'PMR EMERGENCY',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFD71920),
          primary: const Color(0xFFD71920),
        ),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF7F7F7),
      ),
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<AuthState>(
      stream: supabase.auth.onAuthStateChange,
      builder: (context, snapshot) {
        if (supabase.auth.currentSession != null) {
          return const HomePage();
        }
        return const AuthPage();
      },
    );
  }
}

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});

  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  bool isRegister = false;
  bool loading = false;
  String message = '';

  Future<void> submit() async {
    setState(() {
      loading = true;
      message = '';
    });
    try {
      final email = emailController.text.trim();
      final password = passwordController.text;
      if (email.isEmpty || password.length < 6) {
        throw Exception('Isi email dan kata sandi minimal 6 karakter.');
      }
      if (isRegister) {
        await supabase.auth.signUp(email: email, password: password);
        setState(() {
          message = 'Pendaftaran dikirim. Jika diminta, cek email untuk verifikasi.';
        });
      } else {
        await supabase.auth.signInWithPassword(
          email: email,
          password: password,
        );
      }
    } on AuthException catch (e) {
      if (mounted) setState(() => message = e.message);
    } on SocketException catch (e) {
      if (mounted) {
        final detail = e.message.toLowerCase();
        setState(() {
          message = detail.contains('failed host lookup')
              ? 'HP gagal menemukan alamat server Supabase (DNS). Server dan akun tidak dihapus. Periksa jaringan/DNS perangkat, lalu coba lagi.'
              : 'Koneksi jaringan gagal: ${e.message}';
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() => message = e.toString().replaceFirst('Exception: ', ''));
      }
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Icon(Icons.health_and_safety,
                      color: Color(0xFFD71920), size: 76),
                  const SizedBox(height: 12),
                  const Text('PMR EMERGENCY',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  const Text('Satu Tekanan, Seluruh Anggota Siaga.',
                      textAlign: TextAlign.center),
                  const SizedBox(height: 32),
                  Text(isRegister ? 'Buat akun anggota' : 'Masuk ke akun',
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 14),
                  TextField(
                    controller: emailController,
                    keyboardType: TextInputType.emailAddress,
                    decoration: const InputDecoration(
                      labelText: 'Email',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: passwordController,
                    obscureText: true,
                    decoration: const InputDecoration(
                      labelText: 'Kata sandi (minimal 6 karakter)',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: loading ? null : submit,
                    child: Text(loading
                        ? 'Memproses...'
                        : (isRegister ? 'DAFTAR' : 'MASUK')),
                  ),
                  TextButton(
                    onPressed: loading
                        ? null
                        : () => setState(() {
                              isRegister = !isRegister;
                              message = '';
                            }),
                    child: Text(isRegister
                        ? 'Sudah punya akun? Masuk'
                        : 'Belum punya akun? Daftar'),
                  ),
                  if (message.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text(message, textAlign: TextAlign.center,
                        style: const TextStyle(color: Color(0xFFB3261E))),
                  ],
                  const SizedBox(height: 24),
                  const Text(
                    'Tahap awal: akun dan koneksi server. Fitur grup sekolah, lokasi, '
                    'notifikasi, dan SOS belum diaktifkan.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 12, color: Colors.black54),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final email = supabase.auth.currentUser?.email ?? 'Anggota PMR';
    return Scaffold(
      appBar: AppBar(
        title: const Text('PMR EMERGENCY'),
        actions: [
          IconButton(
            tooltip: 'Keluar',
            onPressed: () async => supabase.auth.signOut(),
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Icon(Icons.health_and_safety,
              size: 72, color: Color(0xFFD71920)),
          const SizedBox(height: 12),
          const Text('Selamat datang!',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          Text(email, textAlign: TextAlign.center),
          const SizedBox(height: 24),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(18),
              child: Column(
                children: [
                  Icon(Icons.construction, size: 34),
                  SizedBox(height: 8),
                  Text('Aplikasi sedang dibangun',
                      style: TextStyle(fontWeight: FontWeight.bold)),
                  SizedBox(height: 6),
                  Text(
                    'Koneksi akun ke Supabase sudah disiapkan. '
                    'Tombol DARURAT belum tersedia sampai alur lokasi, '
                    'izin keamanan, dan notifikasi selesai diuji.',
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'Penting: aplikasi ini nantinya menjadi alat koordinasi tambahan, '
            'bukan pengganti layanan darurat resmi.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 12, color: Colors.black54),
          ),
        ],
      ),
    );
  }
}
