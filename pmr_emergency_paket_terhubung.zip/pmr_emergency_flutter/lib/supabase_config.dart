// Konfigurasi Supabase PMR EMERGENCY.
// Publishable key boleh dipakai di aplikasi. JANGAN pernah memasukkan
// service_role key atau secret key ke aplikasi.
const String supabaseUrl = 'https://ohrjcryavbljkpjqcbxc.supabase.co';
const String supabasePublishableKey =
    'sb_publishable_06FNKGYFiebdBkoVySmrPQ_mQ-CyMll';
